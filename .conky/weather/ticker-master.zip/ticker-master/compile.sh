gcc -Wall -std=gnu99 -o ticker ticker.c
